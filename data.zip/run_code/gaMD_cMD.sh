#!/bin/bash

# ================= 环境设置 =================
export PATH=/home/phzd/test/amber20/miniconda/bin:$PATH
source /home/phzd/test/amber20/amber.sh
export LD_LIBRARY_PATH=/opt/openmpi_v403/lib:$LD_LIBRARY_PATH
export PATH=/opt/openmpi_v403/bin:$PATH && echo "using openmpi403"

# 设置显卡
export CUDA_VISIBLE_DEVICES=2

# 运行程序
amber="pmemd.cuda"

# ================= 步骤与前缀定义 =================
init="step5_input"
mini_prefix="step6.0_minimization"
equi_prefix="step6.%d_equilibration"
equi_prefix_Ga="step6.6_equilibration" # 特定平衡阶段的前缀，用于GaMD准备

long_cMD_prefix="step7_production"  # 新增：长常规生产平衡前缀（100 ns）

GaMD_prerun="pre_GaMD_init" # GaMD预运行的前缀，用于参数收集
prod_prefix="GaMD" # 生产模拟的前缀，用于采样阶段

# ================= 1. 能量最小化 =================
echo ">>> [Step 1] Minimization"
# 输入文件：
#   - step5_input.rst7 (.rst7 坐标，重启文件)
#   - step5_input.parm7 (.parm7 拓扑)
#   - step6.0_minimization.mdin (最小化输入)
#   - dihe.restraint 模板 → 生成 step6.0_minimization.rest
# 输出文件：
#   - step6.0_minimization.rst7 (重启坐标，用于下一步equi输入)
#   - step6.0_minimization.mdout / .mdinfo / .rest
if [ -f dihe.restraint ]; then
    sed -e "s/FC/250.0/g" dihe.restraint > ${mini_prefix}.rest
else
    echo "Error: dihe.restraint file not found!"
    exit 1
fi

$amber -O -i ${mini_prefix}.mdin -p ${init}.parm7 -c ${init}.rst7 -o ${mini_prefix}.mdout -r ${mini_prefix}.rst7 -inf ${mini_prefix}.mdinfo -ref ${init}.rst7

# ================= 2. 平衡阶段 =================
echo ">>> [Step 2] Equilibration"
cnt=1
cntmax=6
# 定义力常数数组 (共6个值)
fc=('250.0' '100.0' '50.0' '50.0' '25.0' '10.0')

while [ ${cnt} -le ${cntmax} ]; do
    pcnt=$((cnt - 1))
    istep=$(printf ${equi_prefix} ${cnt})
    pstep=$(printf ${equi_prefix} ${pcnt})
   
    if [ ${cnt} -eq 1 ]; then
        pstep=${mini_prefix}
    fi
    # [修正]: 将 -lt 改为 -le，确保最后一步也能更新约束文件
    if [ -e dihe.restraint ] && [ ${cnt} -le ${cntmax} ]; then
        # 再次确认数组不越界
        if [ $((cnt-1)) -lt ${#fc[@]} ]; then
            echo "Updating restraint for step ${cnt}: FC = ${fc[$((cnt-1))]}"
            sed -e "s/FC/${fc[$((cnt-1))]}/g" dihe.restraint > ${istep}.rest
        fi
    fi
   
    # 输入文件：
    #   - 上一步的 .rst7 (-c)
    #   - step5_input.parm7
    #   - 当前 step6.x_equilibration.mdin
    #   - 当前生成的 .rest 约束文件
    # 输出文件：
    #   - step6.x_equilibration.rst7 (重启坐标，用于下一步)
    #   - step6.x_equilibration.nc (轨迹)
    #   - step6.x_equilibration.mdout / .mdinfo / .rest
    $amber -O -i ${istep}.mdin -p ${init}.parm7 -c ${pstep}.rst7 -o ${istep}.mdout -r ${istep}.rst7 -inf ${istep}.mdinfo -ref ${init}.rst7 -x ${istep}.nc
   
    cnt=$((cnt + 1))
done

# ================= 2.5. 长常规生产平衡（新增，确保系统充分稳定） =================
echo ">>> [Step 2.5] Long Conventional Production (100 ns)"
# 输入文件：
#   - step6.6_equilibration.rst7 (从equi最后一步接)
#   - step5_input.parm7
#   - step7_production.mdin (您的常规100 ns mdin)
# 输出文件：
#   - long_cMD_production.rst7 (重启坐标，用于GaMD pre-run输入)
#   - long_cMD_production.nc (轨迹，用于检查稳定性)
#   - long_cMD_production.mdout / .mdinfo
$amber -O -i ${long_cMD_prefix}.mdin -p ${init}.parm7 -c ${equi_prefix_Ga}.rst7 -o ${long_cMD_prefix}.mdout -r ${long_cMD_prefix}.rst7 -inf ${long_cMD_prefix}.mdinfo -x ${long_cMD_prefix}.nc

# # ================= 3. 参数收集 GaMD 准备 =================
# echo ">>> [Step 3] GaMD Pre-run"
# 输入文件：
#   - long_cMD_production.rst7 (从长常规生产接，确保起点稳)
#   - step5_input.parm7
#   - pre_GaMD_init.mdin (您的优化版50 ns pre-run)
# 输出文件：
#   - pre_GaMD_init.rst7 (含GaMD参数的重启文件，用于生产第一步)
#   - pre_GaMD_init.nc (轨迹)
#   - pre_GaMD_init.mdout / .mdinfo
#   - gamd.log (boost参数，备份)
"$amber" -O -i "${GaMD_prerun}.mdin" -p "${init}.parm7" -c "${long_cMD_prefix}.rst7" -o "${GaMD_prerun}.mdout" -r "${GaMD_prerun}.rst7" -inf "${GaMD_prerun}.mdinfo" -x "${GaMD_prerun}.nc"

# 备份 gamd.log
cp gamd.log "gamd_${GaMD_prerun}.log"

# ================= 4. 采样 生产模拟 =================
echo ">>> [Step 4] GaMD Production"
# 100 ns * 10 = 1 us
cnt=1
cntmax=10

while [ ${cnt} -le ${cntmax} ]; do
    pcnt=$((cnt-1))
    istep="${prod_prefix}_${cnt}"
    pstep="${prod_prefix}_${pcnt}"
   
    # 关键逻辑: 第一步必须接在 pre_GaMD_init 之后
    if [ ${cnt} -eq 1 ]; then
        pstep="${GaMD_prerun}"
    fi

    # 输入文件：
    #   - 上一步的 .rst7 (-c，第一步从pre-run)
    #   - step5_input.parm7
    #   - GaMD.mdin (生产输入)
    # 输出文件：
    #   - GaMD_x.rst7 (重启坐标，用于下一步)
    #   - GaMD_x.nc (轨迹)
    #   - GaMD_x.mdout / .mdinfo
    #   - gamd_*.log (每段boost备份)
    "$amber" -O -i "${prod_prefix}.mdin" -p "${init}.parm7" -c "${pstep}.rst7" -o "${istep}.mdout" -r "${istep}.rst7" -inf "${istep}.mdinfo" -x "${istep}.nc"

    cp gamd.log "gamd_${istep}.log"
    cnt=$((cnt+1))
done

echo ">>> All Done!"

